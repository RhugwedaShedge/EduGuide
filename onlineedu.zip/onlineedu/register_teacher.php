<?php
include 'connection.php';
error_reporting(0);

if(isset($_POST['submit']))
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "onlineedu";

    $T_FNAME = $_POST['T_FNAME'];
    $T_LNAME = $_POST['T_LNAME'];
    $T_EMAIL = $_POST['T_EMAIL'];
    $T_PHONE_NO = $_POST['T_PHONE_NO'];
    $T_QUALIFICATION = $_POST['T_QUALIFICATION'];
    $T_PASSWORD = $_POST['T_PASSWORD'];



// Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);

    $query ="INSERT INTO `teacher` (`F_NAME`, `L_NAME`, `E-MAIL`, `PHONE_NO`, `QUALIFICATION`, `PASSWORD`) VALUES ('$T_FNAME', '$T_LNAME', '$T_EMAIL', '$T_PHONE_NO', '$T_QUALIFICATION', '$T_PASSWORD');";
    $sql="INSERT INTO `login_teacher` (`F_NAME`, `L_NAME`, `E-MAIL`, `PASSWORD`) VALUES ('$T_FNAME', '$T_LNAME', '$T_EMAIL', '$T_PASSWORD')";


    $result = mysqli_query($conn,$query);
    $result_sql = mysqli_query($conn,$sql);

    if($result)
    {
        echo 'YOU HAVE REGISTERED. WELCOME TO OUR WEBSITE.';
    
    }
    else{
      echo "data not inserted due to error ".mysqli_error($conn);
    }

    mysqli_free_result($result);
    mysqli_close($conn);

}

?>
<style>
 * {
 margin: 0px;
 padding: 0px;
}
body{
    background-image: url("images/loginphoto.jpg");
     height: 100%;
 /* Center and scale the image nicely */
 background-position: center;
 background-repeat: no-repeat;
 background-size: cover;
 margin-top: 30px;
 font-size: 120%;
 font-family: 'Overlock', cursive;
 display: flex;
}
.reg_img{
  width: 100%;
  position: absolute;
  z-index: -1;
  opacity: 0.7;
}

.input-group {
  margin: 10px 0px 10px 0px;
}
.input-group label {
  display: block;
  text-align: left;
  margin: 3px;
}
.input-group input {
  height: 30px;
  width: 93%;
  padding: 5px 10px;
  font-size: 16px;
  border-radius: 5px;
  border: 1px solid gray;
}

.btn{
  padding: 10px;
  font-size: 15px;
  color: white;
  background: #086972;
  border: solid black;
  border-radius: 34px;
  margin-top: 20px;
  width: 101px;
  height: 50px;
  font-size: 21px;
}
</style>
<!DOCTYPE html>
<html>
    <head>
      <title>Register User</title>
      <link rel="stylesheet" href="css.css">
    </head>

    <body >

        <h3>Registration page</h3>
      

        <form action="register_teacher.php" method="post">

          <div class="input-group">
            <label>First Name </label>
            <input type="text" name="T_FNAME" value="">
          </div>

          <div class="input-group">
            <label>Last Name </label>
            <input type="text" name="T_LNAME" value="">
          </div>

          <div class="input-group">
            <label>Email</label>
            <input type="text" name="T_EMAIL" value=""/>
          </div>

          <div class="input-group">
            <label>Phone no</label>
            <input type="text" name="T_PHONE_NO" value=""/>
          </div>

          <div class="input-group">
            <label>Password </label>
            <input type="text" name="T_PASSWORD" value="">
          </div>

          <div class="input-group">
            <label>Confirm Password </label>
            <input type="text" name="T_PASSWORD_C" value="">
          </div>

          <div class="input-group">
            <center><button type="submit" class="btn" name="submit">Submit</button></center>
          </div>

        </form>






</body>
</html>